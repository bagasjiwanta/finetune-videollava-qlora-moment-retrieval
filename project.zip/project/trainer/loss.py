
def mr_moment_loss():
    pass

def mr_l1_loss():
    pass